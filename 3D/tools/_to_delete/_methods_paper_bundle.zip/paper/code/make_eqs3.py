"""Every display equation in the manuscript, typeset with LaTeX at 600 dpi.

These follow the code in PRT-DeepONet/3D exactly: the chemistry is the one in
tools/settings_and_units.py, and the network is model/deeponet_model.py.
"""
import os, subprocess, shutil

OUT = "/home/claude/figs/eq"
TMP = "/tmp/eqbuild3"
os.makedirs(OUT, exist_ok=True)
shutil.rmtree(TMP, ignore_errors=True); os.makedirs(TMP)

EQ = {
 # ------------------------------------------------ lattice Boltzmann, flow ---
 "e01": r"f_i(\mathbf{x}+\mathbf{c}_i\,\Delta t,\ t+\Delta t)=f_i(\mathbf{x},t)"
        r"-\omega^{+}\bigl[f_i^{+}-f_i^{eq,+}\bigr]"
        r"-\omega^{-}\bigl[f_i^{-}-f_i^{eq,-}\bigr]+F_i",
 "e02": r"f_i^{eq}=w_i\,\rho\left[1+\frac{\mathbf{c}_i\cdot\mathbf{u}}{\tilde{c}_s^{2}}"
        r"+\frac{(\mathbf{c}_i\cdot\mathbf{u})^{2}}{2\,\tilde{c}_s^{4}}"
        r"-\frac{\mathbf{u}\cdot\mathbf{u}}{2\,\tilde{c}_s^{2}}\right]",
 "e03": r"f_i^{\pm}=\frac{1}{2}\bigl(f_i\pm f_{\bar{\imath}}\bigr),\qquad"
        r"\tilde{\nu}=\tilde{c}_s^{2}\left(\frac{1}{\omega^{+}}-\frac{1}{2}\right),\qquad"
        r"\Lambda=\left(\frac{1}{\omega^{+}}-\frac{1}{2}\right)"
        r"\left(\frac{1}{\omega^{-}}-\frac{1}{2}\right)=\frac{3}{16}",
 "e04": r"F_i=\left(1-\frac{\omega^{-}}{2}\right)w_i"
        r"\left[\frac{\mathbf{c}_i-\mathbf{u}}{\tilde{c}_s^{2}}"
        r"+\frac{(\mathbf{c}_i\cdot\mathbf{u})\,\mathbf{c}_i}{\tilde{c}_s^{4}}\right]"
        r"\cdot\mathbf{g}",
 "e05": r"\rho=\sum_i f_i,\qquad\qquad"
        r"\rho\,\mathbf{u}=\sum_i \mathbf{c}_i\,f_i+\frac{1}{2}\,\mathbf{g}\,\Delta t",
 # ------------------------------------------------ transport -----------------
 "e06": r"\frac{\partial C_j}{\partial t}+\nabla\!\cdot\!\left(\mathbf{u}\,C_j\right)"
        r"=\nabla\!\cdot\!\left(D_j\,\nabla C_j\right)+R_j",
 "e07": r"C_j^{\,n+1}=C_j^{\,n}-\frac{\Delta t}{\Delta x}"
        r"\sum_{\mathrm{faces}}\left(J^{\mathrm{adv}}+J^{\mathrm{dif}}\right)"
        r"+\Delta t\,R_j",
 "e08": r"C_{\mathrm{face}}=C_{\mathrm{up}}+\frac{1}{2}\,"
        r"\mathrm{minmod}\bigl(\Delta_{\mathrm{up}},\Delta_{\mathrm{down}}\bigr),"
        r"\qquad\mathrm{minmod}(a,b)=\begin{cases}"
        r"a & |a|<|b|,\ ab>0\\[2pt] b & |b|\le|a|,\ ab>0\\[2pt] 0 & ab\le 0"
        r"\end{cases}",
 "e09": r"D_{\mathrm{face}}=\frac{2\,D_L\,D_R}{D_L+D_R}",
 # ------------------------------------------------ the reaction network ------
 "e10": r"\mathrm{Ac}\;+\;\gamma\,\mathrm{A}\ \xrightarrow{\ \ \mathrm{Bio}\ \ }\ "
        r"\mathrm{P}\;+\;Y\,\mathrm{Bio}"
        r"\qquad\qquad\qquad \mathrm{P}\ \xrightarrow{\ \ \text{grain surface}\ \ }\ "
        r"\text{consumed}",
 "e11": r"R_{\mathrm{bio}}=v_{\max}\;C_{\mathrm{Bio}}\;"
        r"\frac{C_{\mathrm{Ac}}}{K_{\mathrm{Ac}}+C_{\mathrm{Ac}}}\;"
        r"\frac{C_{\mathrm{A}}}{K_{\mathrm{A}}+C_{\mathrm{A}}}",
 "e12": r"R_{\mathrm{abio}}=\sigma\,k_{\mathrm{surf}}\,C_{\mathrm{P}},"
        r"\qquad\qquad \sigma=\begin{cases}1 & \text{the voxel touches a grain}\\"
        r"0 & \text{otherwise}\end{cases}",
 "e13": r"\frac{\partial C_{\mathrm{Bio}}}{\partial t}"
        r"=Y\,R_{\mathrm{bio}}-k_{\mathrm{dec}}\,C_{\mathrm{Bio}}",
 "e14": r"Pe=\frac{U\,L}{D},\qquad\qquad Da=\frac{v_{\max}\,L}{U},"
        r"\qquad\qquad Da_{\mathrm{abio}}=\frac{k_{\mathrm{surf}}\,L}{U}",
 # ------------------------------------------------ geometry ------------------
 "e15": r"\left|\nabla\phi\right|=1\ \ \text{in the pore space},\qquad"
        r"\phi=0\ \ \text{on the inlet face},\qquad"
        r"\phi\to\infty\ \ \text{inside the solid}",
 "e16": r"\psi(\mathbf{x})=\min_{\mathbf{y}\,\in\,\text{solid}}"
        r"\left\|\mathbf{x}-\mathbf{y}\right\|",
 # ------------------------------------------------ the operator --------------
 "e17": r"G(w)(\mathbf{p})\ \approx\ \sum_{i=1}^{p} B(w)_i\ T(\mathbf{p})_i\ +\ b_0",
 "e18": r"\hat{C}_n(\mathbf{p})=\sum_{i=1}^{p}"
        r"\Bigl[W\bigl(B_C(\mathbf{w})\odot B_F(\mathbf{r})\bigr)\Bigr]_{n,i}"
        r"\;T(\mathbf{p})_i\;+\;b_n,"
        r"\qquad n=1\ldots N_{\text{species}}",
 "e19": r"\mathbf{h}^{(\ell)}\ \leftarrow\ \mathbf{h}^{(\ell)}\odot"
        r"\bigl[\mathbf{1}+\boldsymbol{\gamma}(\phi)\bigr]+\boldsymbol{\beta}(\phi),"
        r"\qquad \ell=3,\,6",
 # ------------------------------------------------ error metrics -------------
 "e20": r"RMSE_n=\sqrt{\frac{1}{N}\sum_{\mathbf{p}\,\in\,\mathrm{pore}}"
        r"\bigl[\hat{C}_n(\mathbf{p})-C_n(\mathbf{p})\bigr]^{2}}",
 "e21": r"R^{2}_{n}=1-\frac{\sum\bigl[\hat{C}_n(\mathbf{p})-C_n(\mathbf{p})\bigr]^{2}}"
        r"{\sum\bigl[C_n(\mathbf{p})-\overline{C_n}\bigr]^{2}}",
}

DOC = r"""\documentclass[border=2pt,varwidth=470pt]{standalone}
\usepackage{amsmath,amssymb,mathptmx}
\begin{document}
$\displaystyle %s$
\end{document}
"""

fail = []
for name, tex in EQ.items():
    p = os.path.join(TMP, name)
    open(p + ".tex", "w").write(DOC % tex)
    r = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                        "-output-directory", TMP, p + ".tex"],
                       capture_output=True, text=True)
    if r.returncode:
        fail.append(name)
        print("FAILED", name)
        print("\n".join(l for l in r.stdout.splitlines() if l.startswith("!"))[:300])
        continue
    subprocess.run(["pdftocairo", "-png", "-transp", "-singlefile", "-r", "600",
                    p + ".pdf", os.path.join(OUT, name)], check=True)

from PIL import Image
for name in EQ:
    f = os.path.join(OUT, name + ".png")
    if os.path.exists(f):
        w, h = Image.open(f).size
        print(f"  {name}  {w}x{h}  ->  {w/600:.2f} in wide")
print("failed:", fail if fail else "none")

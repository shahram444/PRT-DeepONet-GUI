// PRT-LB 3D + PRT-DeepONet 3D: methods paper, written for reactive-transport
// readers. Results, Discussion and Conclusions are placeholders.
const d = require('docx');
const fs = require('fs');
const { execSync } = require('child_process');
const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
        ImageRun, Table, TableRow, TableCell, WidthType, BorderStyle,
        PageBreak, LineRuleType, VerticalAlign } = d;

const F = '/home/claude/figs/';
const V3 = F + 'v3/';
const EQ = F + 'eq/';
const SER = 'Cambria', SANS = 'Calibri';
const INK = '111111', MUT = '4A4A52', HOLD = '9A3B3B';
const W = 9360;
const AUTO = LineRuleType.AUTO;

// ------------------------------------------------------------------ helpers --
const P = (t, o = {}) => new Paragraph({
  children: Array.isArray(t) ? t : [new TextRun({ text: t, font: SER, size: 21, color: INK })],
  spacing: { after: o.after ?? 130, line: o.line ?? 300, lineRule: AUTO },
  alignment: o.align, indent: o.indent });

const H1 = t => new Paragraph({ text: t, heading: HeadingLevel.HEADING_1,
  spacing: { before: 320, after: 150, line: 280, lineRule: AUTO } });
const H2 = t => new Paragraph({ text: t, heading: HeadingLevel.HEADING_2,
  spacing: { before: 260, after: 110, line: 280, lineRule: AUTO } });
const H3 = t => new Paragraph({ text: t, heading: HeadingLevel.HEADING_3,
  spacing: { before: 210, after: 90, line: 280, lineRule: AUTO } });

const tx = t => new TextRun({ text: t, font: SER, size: 21, color: INK });
const it = t => new TextRun({ text: t, font: SER, size: 21, color: INK, italics: true });
const bd = t => new TextRun({ text: t, font: SER, size: 21, color: INK, bold: true });
const sub = t => new TextRun({ text: t, font: SER, size: 21, color: INK, subScript: true });

const dim = f => execSync(
  `python3 -c "from PIL import Image;im=Image.open('${f}');print(im.size[0],im.size[1])"`)
  .toString().trim().split(' ').map(Number);

function pic(file, widthIn, caption) {
  const [w, h] = dim(file);
  const wp = widthIn * 96, hp = wp * h / w;
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true,
      spacing: { before: 200, after: 70, line: 240, lineRule: AUTO },
      children: [new ImageRun({ type: 'png', data: fs.readFileSync(file),
        transformation: { width: wp, height: hp } })] }),
    new Paragraph({ keepLines: true,
      spacing: { after: 240, line: 260, lineRule: AUTO },
      children: [new TextRun({ text: caption, font: SANS, size: 17, color: MUT })] }),
  ];
}

const NONE = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const RULE = s => ({ style: BorderStyle.SINGLE, size: s, color: '111111' });

function eq(file, num) {
  // The equations are all typeset at one LaTeX size and exported at 600 dpi, so
  // px/600 is the true width in inches; using it keeps every glyph in the paper
  // identical. Capped at the width of the cell.
  const [w, h] = dim(EQ + file);
  const inches = Math.min(w / 600, 5.6);
  const wp = inches * 96, hp = wp * h / w;
  const cell = (children, width, align) => new TableCell({
    width: { size: width, type: WidthType.DXA },
    borders: { top: NONE, bottom: NONE, left: NONE, right: NONE },
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: 100, bottom: 100, left: 0, right: 0 },
    children: [new Paragraph({ alignment: align,
      spacing: { before: 0, after: 0, line: 240, lineRule: AUTO }, children })] });
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [8460, 900],
    borders: { top: NONE, bottom: NONE, left: NONE, right: NONE,
               insideHorizontal: NONE, insideVertical: NONE },
    rows: [new TableRow({ cantSplit: true, children: [
      cell([new ImageRun({ type: 'png', data: fs.readFileSync(EQ + file),
             transformation: { width: wp, height: hp } })], 8460, AlignmentType.CENTER),
      cell([tx('(' + num + ')')], 900, AlignmentType.RIGHT)] })] });
}

// Minimal, rule-only table: a rule above the header, one below it, one at the foot.
function table(num, title, rows, widths, opts = {}) {
  const last = rows.length - 1;
  const t = new Table({
    columnWidths: widths,
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    rows: rows.map((r, i) => new TableRow({
      tableHeader: i === 0, cantSplit: true,
      children: r.map((c, j) => new TableCell({
        width: { size: widths[j], type: WidthType.DXA },
        borders: { left: NONE, right: NONE,
                   top: i === 0 ? RULE(9) : NONE,
                   bottom: i === 0 ? RULE(4) : (i === last ? RULE(9) : NONE) },
        margins: { top: 55, bottom: 55, left: 0, right: 130 },
        children: [new Paragraph({
          keepNext: i < last,
          spacing: { after: 0, line: 240, lineRule: AUTO },
          children: String(c).split('~').map((seg, q) => new TextRun({
            text: seg, font: SANS, size: opts.size ?? 16, color: INK,
            subScript: q % 2 === 1,
            bold: i === 0 || (opts.bold || []).includes(i) })) })] })) })) });
  return [
    new Paragraph({ keepNext: true, spacing: { before: 220, after: 20, line: 250, lineRule: AUTO },
      children: [new TextRun({ text: 'Table ' + num, font: SANS, size: 17, bold: true, color: INK })] }),
    new Paragraph({ keepNext: true, spacing: { after: 90, line: 250, lineRule: AUTO },
      children: [new TextRun({ text: title, font: SANS, size: 17, color: MUT })] }),
    t,
    new Paragraph({ text: '', spacing: { after: 200 } }),
  ];
}

// A visible, unmistakable placeholder block.
function placeholder(lines) {
  const cell = new TableCell({
    width: { size: W, type: WidthType.DXA },
    borders: { top: RULE(6), bottom: RULE(6), left: RULE(6), right: RULE(6) },
    margins: { top: 160, bottom: 160, left: 160, right: 160 },
    children: lines.map((l, i) => new Paragraph({
      spacing: { after: i === lines.length - 1 ? 0 : 90, line: 280, lineRule: AUTO },
      children: [new TextRun({ text: l, font: SANS, size: 18,
                               color: i === 0 ? HOLD : MUT,
                               bold: i === 0, italics: i > 0 })] })) });
  return [new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [W],
                      rows: [new TableRow({ children: [cell] })] }),
          new Paragraph({ text: '', spacing: { after: 220 } })];
}

// ================================================================= CONTENT ===
const k = [];

k.push(new Paragraph({ spacing: { after: 110, line: 300, lineRule: AUTO },
  children: [new TextRun({ text: 'A pore-scale reactive transport simulator and a '
    + 'geometry-aware neural operator for three-dimensional porous media',
    font: SER, size: 32, bold: true, color: INK })] }));
k.push(P([tx('Shahram Asgari'), new TextRun({ text: '1*', font: SER, size: 21, superScript: true }),
          tx(', Christof Meile'), new TextRun({ text: '1', font: SER, size: 21, superScript: true })],
         { after: 50 }));
k.push(P([new TextRun({ text: '1', font: SER, size: 19, superScript: true, color: MUT }),
          new TextRun({ text: 'Department of Marine Sciences, University of Georgia, Athens, GA 30602, USA',
                        font: SER, size: 19, color: MUT })], { after: 40 }));
k.push(P([new TextRun({ text: '*Corresponding author: shahram.asgari@uga.edu', font: SER, size: 19, color: MUT })],
         { after: 40 }));
k.push(P([new TextRun({ text: 'ORCID Shahram Asgari: 0009-0004-3810-2739;  Christof Meile: 0000-0002-0825-4596',
                        font: SER, size: 19, color: MUT })], { after: 260 }));

// ------------------------------------------------------------------ abstract --
k.push(H1('Abstract'));
k.push(P('Pore-scale reactive transport models resolve the grains, the flow between them, and the reaction where the reactants actually meet. That is why they reproduce effective rates a continuum formulation cannot, and it is also why they are used sparingly: a three-dimensional case takes hours. Questions that need many cases, such as how an effective rate constant varies over a population of media, are therefore rarely asked.'));
k.push(P('We present two coupled pieces of software and the workflow that connects them. PRT-LB 3D is a pore-scale simulator: it generates the medium, solves Stokes flow with a three-dimensional lattice Boltzmann scheme, and solves advection, diffusion and a four-species reaction network on the same voxel grid, writing everything into a single HDF5 file. It is deliberately not a reimplementation of CompLaB3D, which remains the reference simulator; it exists so that a whole training set can be built on one machine in an afternoon, which is what a neural operator needs and what a cluster queue cannot give. Section 2.2 states exactly where the two differ, part by part.'));
k.push(P('PRT-DeepONet 3D is the surrogate: a geometry-aware neural operator that takes a pore structure, a set of dimensionless groups and a query point, and returns the concentration of every species at that point and that instant. It extends the two-dimensional formulation of Kim, Kim and Jung to three dimensions, to four species, and to the transient, and it re-injects the geodesic distance part way down the trunk so that depth cannot wash the geometry out.'));
k.push(P('Three optional modes address the fact that three-dimensional training data are the scarce resource: the trunk may be given the advective travel time from the solved flow instead of the geodesic distance from the geometry; two-dimensional media extruded along the third axis may be added to the training set, where they are not an approximation but genuine members of the three-dimensional problem class; and the Cartesian coordinates may be dropped entirely so that one trunk serves both dimensions. All three default to off, and with all three off the code reproduces the original behaviour exactly.'));

k.push(P([bd('Keywords  '), tx('pore-scale modelling; reactive transport; lattice Boltzmann; '
  + 'neural operator; DeepONet; geodesic distance; travel time')], { after: 240 }));

// ========================================================== 1 INTRODUCTION ===
k.push(H1('1.  Introduction'));
k.push(P('Reaction rates measured in the laboratory and rates inferred in the field routinely disagree, sometimes by orders of magnitude. A large part of that gap is not chemistry but transport: reactants and reactive surfaces are not mixed uniformly at the pore scale, so the volume-averaged rate a continuum model computes is not the rate that actually occurs. Pore-scale models address this directly, and their cost is the reason they are used sparingly.'));
k.push(P('This paper describes the two halves of a workflow built to make that cost tractable. The first half is a simulator written to generate training data rather than to replace a reference code. The second is a neural operator that, once trained, returns a full concentration field for a medium it has never seen. Section 2 describes both, and the three optional modes that attack the cost of the training set itself. Sections 3 to 5 report what they do.'));

k.push(...pic(V3 + 'f_pipeline.png', 6.5,
  'Fig. 1.  The whole workflow. The experiment is described once, in a settings file or in the window; the generator then builds every structure and every combination of conditions without supervision and writes them into one HDF5 file. The middle band shows what a single run solves: the pore structure, the flow through it, and the transport and reaction on top of that. The trained operator replaces the last of those three, and the three optional modes attach at the training stage.'));

// ============================================================== 2 METHODS ====
k.push(H1('2.  Methods'));

k.push(H2('2.1.  How a study is set up and run'));
k.push(P('A study is described by one settings file, in XML or JSON, which holds the grid, the flow, the chemistry, and the conditions to sweep. Every quantity that varies may be given either as a range, from which each run draws a value logarithmically, or as an explicit list of the exact numbers wanted; a list of three Peclet numbers crossed with two Damkohler numbers is six conditions per structure. Porosity works the same way but applies to the structures: a list builds them at exactly those porosities, cycling in order. The same file drives the generator, the trainer and the evaluator, so a study is reproduced by re-running it, and the file that made a dataset is copied into the dataset.'));
k.push(P('The generator runs unattended and writes a single HDF5 file holding the geometry of every structure, both distance fields, the solved velocity, the concentration of every species at every stored time, the conditions each run was given, and the settings that produced them. Nothing is written anywhere else. Every stage is one command, or one page in a graphical interface that emits the same command, so the same study can be set up by someone who does not want to use a terminal.'));

k.push(H2('2.2.  PRT-LB 3D:  the simulator'));
k.push(P('Fig. 2 shows the four things the simulator does, in the order it does them. This section states each of them and, at the end of each, how it differs from CompLaB3D. That comparison matters because the two are used for different purposes: CompLaB3D is the reference, the code a mechanism is published from; PRT-LB 3D exists so that hundreds of runs can be produced on one machine, which is what training a neural operator requires.'));

k.push(...pic(V3 + 'f_prtlb.png', 6.5,
  'Fig. 2.  PRT-LB 3D, in the order the code executes. Stages 1 and 2 are paid once per structure, because the pore space never changes and Stokes flow does not depend on the chemistry; stage 3 is paid once per set of conditions. Panel 4 marks the pore voxels that touch a grain, which is where a mineral-surface reaction is allowed to run.'));

k.push(H3('2.2.1.  Geometry'));
k.push(P('A structure is built by smoothing an uncorrelated random field with a Gaussian filter, which sets the correlation length, and then cutting it at the value that gives the requested porosity. Voxels above the cut are solid. The first and last few slices are opened completely to make inlet and outlet buffers, the four lateral faces are sealed, and any pore space the inlet cannot reach is filled in with solid before anything is solved, because it carries no flow, receives no solute, and would otherwise present the network with pore voxels whose concentration is zero for reasons it cannot see. Because those three operations change the pore fraction after the cut, the threshold is adjusted until the porosity of the stored structure is the one that was asked for.'));
k.push(P([bd('Compared with CompLaB3D.  '), tx('CompLaB3D takes a pore structure as given, typically a segmented image. PRT-LB 3D generates its own, because a training set needs a population of structures rather than one, and because the porosity and correlation length then become controlled variables rather than properties of whichever sample was scanned. Nothing prevents an imported image being used instead; the rest of the pipeline never asks where the geometry came from.')]));

k.push(H3('2.2.2.  Flow'));
k.push(P('At pore velocities of interest the Reynolds number is far below one, so inertia is negligible and the flow satisfies the Stokes equations with no slip at every grain surface. These are solved on a three-dimensional lattice with 19 discrete velocity directions, in which the distribution functions evolve as'));
k.push(eq('e01.png', 1));
k.push(P([tx('where '), it('f'), sub('i'), tx(' is the particle distribution function along direction '), it('i'),
          tx(' at position '), bd('x'), tx(' and time '), it('t'), tx(', '), bd('c'), sub('i'),
          tx(' is the lattice velocity, and '), it('F'), sub('i'), tx(' is the forcing term. The equilibrium distribution is')]));
k.push(eq('e02.png', 2));
k.push(P([tx('with '), it('w'), sub('i'), tx(' the lattice weights, '), it('ρ'), tx(' the local density and '),
          it('c̃'), sub('s'), tx('² = 1/3. The collision uses two relaxation rates rather than one: the distributions are split into a part symmetric under reversal of the lattice direction and a part antisymmetric, and each relaxes at its own rate,')]));
k.push(eq('e03.png', 3));
k.push(P('The reason is a measurable defect of the single-rate scheme. With one relaxation rate the effective no-slip surface does not sit at the face of the solid voxel, and its position moves as the relaxation time changes, so the computed permeability of a fixed structure depends on a purely numerical setting. Holding the product at 3/16 pins that surface halfway between the last fluid voxel and the first solid one, independent of viscosity, which is where a lattice Boltzmann wall belongs. No slip is imposed by halfway bounce-back, which reverses the populations arriving at a solid face.'));
k.push(H3('How the flow is actually driven'));
k.push(P('This is worth stating plainly, because it is the question a reactive transport modeller asks first. The flow is not driven by fixing a pressure at the inlet face and another at the outlet. It is driven by a uniform body force applied to every fluid voxel, with the streaming periodic along the flow direction,'));
k.push(eq('e04.png', 4));
k.push(P([tx('and the macroscopic fields follow from the distributions as')]));
k.push(eq('e05.png', 5));
k.push(P('A pressure gradient that is uniform along the flow direction is exactly equivalent to a uniform body force per unit volume, so this is a pressure-driven flow; the force is simply the form a lattice Boltzmann solver can apply without imposing anything on faces that cut through a rough pore structure. That equivalence is why the setting is called a pressure drop.'));
k.push(P('The user does not normally choose that number. Because the Stokes equations are linear, the field is solved once with a seed gradient and then rescaled: doubling the driving force doubles the velocity everywhere and leaves the pattern unchanged. So the user asks for a Peclet number, and the solver reports the pressure gradient that produces it on that particular structure, which differs from structure to structure because a tighter pore network needs a stronger push for the same Peclet number. That, in one sentence, is what permeability means. A user who would rather fix the pressure drop and accept whatever Peclet number it produces can do that instead, and then the Peclet number is computed and recorded per run.'));
k.push(P('The solve is run until the mean velocity has settled rather than for a fixed number of iterations, and it is performed once per structure and reused for every chemistry, since the flow does not depend on the reaction.'));
k.push(P([bd('Compared with CompLaB3D.  '), tx('Both solve incompressible flow through the pore space by lattice Boltzmann with no slip at the grains, and in both the wall sits halfway between the last fluid voxel and the first solid one. CompLaB3D uses a multiple-relaxation-time collision and, crucially, re-solves the flow as biofilm grows and the pore space changes. PRT-LB 3D uses the two-rate form described above and solves the flow once, because its pore space is fixed for the whole run. Any problem in which clogging, precipitation or biofilm growth reroutes the flow is a CompLaB3D problem.')]));

k.push(H3('2.2.3.  Transport'));
k.push(P('Each dissolved species is advected by the flow, spreads by diffusion, and is produced or consumed by reaction,'));
k.push(eq('e06.png', 6));
k.push(P([tx('where '), it('C'), sub('j'), tx(' is the concentration of species '), it('j'), tx(', '),
          it('D'), sub('j'), tx(' its diffusion coefficient and '), it('R'), sub('j'),
          tx(' its net reaction rate. There is no dispersion coefficient in Eq. (6): at this scale the spreading a continuum model represents with a dispersion term arises directly from the resolved velocity field, which is the reason for resolving it. Equation (6) is discretised by finite volumes, with fluxes evaluated on the faces between voxels,')]));
k.push(eq('e07.png', 7));
k.push(P('Three properties follow from writing it that way. Mass is conserved by construction, because what leaves one voxel through a face is exactly what its neighbour receives. The no-flux condition at a grain is exact rather than approximate, because a face against solid carries nothing. And a diffusion coefficient that varies in space is handled by the harmonic mean of the two adjacent values,'));
k.push(eq('e09.png', 8));
k.push(P('Advective face values are reconstructed with a slope limiter rather than by simple upwinding,'));
k.push(eq('e08.png', 9));
k.push(P('Upwinding is stable but is equivalent to adding a numerical diffusion coefficient of about half the local speed times the voxel size, which in these units is comparable to the physical coefficient over the Peclet range of interest. Since the whole purpose of the dataset is to label every run with its Peclet number, a scheme that silently changes that number cannot be used.'));
k.push(P('Unit concentration is imposed at the inlet, a zero-gradient condition at the outlet, and no flux at the lateral boundaries and at every grain surface. Time stepping is explicit, under one combined stability limit, and the run length is set by the field settling rather than by a fixed step count. Snapshots are stored at logarithmically spaced times, so the early transient is resolved as well as the approach to steady state.'));
k.push(P([bd('Compared with CompLaB3D.  '), tx('Both solve advection, diffusion and reaction on the same grid as the flow, with a Dirichlet feed at the inlet, free outflow at the outlet, no flux at the grains, and a diffusion coefficient per chemical. CompLaB3D additionally supports a separate diffusivity inside the biofilm and Dirichlet conditions on the transverse faces. PRT-LB 3D reads a biofilm diffusivity and reports it, but uses the pore value everywhere, because it carries no biofilm volume fraction to interpolate with.')]));

k.push(H3('2.2.4.  Reactions'));
k.push(P('Four species are carried, and their order is what fixes their roles: an electron donor, an electron acceptor, a product, and an attached biomass. Two reactions are available and either may be switched off independently:'));
k.push(eq('e10.png', 10));
k.push(P('The first is microbially mediated and follows dual Monod kinetics, saturating in the donor and the acceptor separately,'));
k.push(eq('e11.png', 11));
k.push(P([tx('where '), it('v'), sub('max'), tx(' is the maximum specific rate and each '), it('K'),
          tx(' is the concentration at which the corresponding factor reaches half its maximum. A half-saturation constant of zero is treated as a distinct case, first order in that species, rather than as a limit of Eq. (11), which is undefined where the species is absent. The second reaction is purely chemical, first order, and may be restricted to the pore voxels that touch a grain, which is what a mineral-surface reaction does,')]));
k.push(eq('e12.png', 12));
k.push(P('Biomass grows from the donor with a yield and decays first order,'));
k.push(eq('e13.png', 13));
k.push(P('and because it is attached it reacts where it is and is never advected. Reaction is applied by operator splitting: transport is advanced first, then concentrations are updated from the local rate expressions, with a cap per reaction that prevents any reaction consuming more of a species than the voxel holds. The cap is evaluated separately for each reaction over only the species that reaction consumes, because a single cap over all species lets one absent species shut down chemistry that does not involve it.'));
k.push(P('Each run is labelled by its dimensionless groups,'));
k.push(eq('e14.png', 14));
k.push(P([bd('Compared with CompLaB3D.  '), tx('Both carry Monod kinetics with dual limitation, biomass growth with a yield and first-order decay, and an abiotic rate constant. Everything else in CompLaB3D\'s chemistry is absent here: aqueous speciation and chemical equilibrium, precipitation and pore voxels turning into solid, surface complexation and mineral surface sites, and many microbial pools each with its own kinetics. PRT-LB 3D has one reaction network and four chemicals. If a problem needs the fifth, it needs CompLaB3D. This is a deliberate boundary, not an omission: a training set has to be generated hundreds of times, and every additional mechanism multiplies both the cost and the number of parameters the surrogate would have to be told about.')]));

k.push(...table(1,
  'Where PRT-LB 3D and CompLaB3D differ. CompLaB3D is the reference simulator; PRT-LB 3D exists to build training sets on one machine. A network trained on PRT-LB 3D data and then evaluated against CompLaB3D output is a fair test of the method; the same network reported as though it had seen CompLaB3D physics is not, which is why every dataset records which generator wrote it.',
  [['', 'PRT-LB 3D', 'CompLaB3D'],
   ['Pore structure', 'generated, a population of them', 'given, typically a segmented image'],
   ['Flow collision', 'two relaxation times, product fixed at 3/16', 'multiple relaxation times'],
   ['Flow re-solved as the pore space changes', 'no, the pore space is fixed', 'yes'],
   ['Driven by', 'a uniform body force, rescaled to the requested Peclet number', 'as configured'],
   ['Transport', 'finite volume, explicit, run to settling', 'lattice Boltzmann on the same grid'],
   ['Biofilm diffusivity', 'read and reported, not used', 'used'],
   ['Transverse boundaries', 'no flux', 'no flux or Dirichlet'],
   ['Chemistry', 'one network, four species', 'speciation, equilibrium, precipitation, surface complexation, many pools'],
   ['Cost per run', 'seconds to minutes on one core', 'hours, on a cluster'],
   ['Intended use', 'building training sets, sweeping conditions', 'the reference runs a paper rests on'],
  ], [2900, 3300, 3160]));

k.push(H2('2.3.  PRT-DeepONet 3D:  the surrogate'));

k.push(H3('2.3.1.  What is being learned'));
k.push(P('The object being learned is an operator: a map that takes a whole pore structure together with a set of conditions and returns a whole concentration field. It is evaluated one query point at a time, so a single point, a profile or a slice can be asked for without computing the rest, and the field can be reconstructed at any resolution. In its general form the deep operator network approximates'));
k.push(eq('e17.png', 15));
k.push(P([tx('where the branch network reads the input function and the trunk reads the coordinate at which the answer is wanted. The trunk supplies a set of basis functions over the domain and the branch supplies the coefficients that combine them. It is the same idea as expanding a solution in eigenfunctions, except that both the basis and the coefficients are learned. For this problem the input is a pair, the structure and the conditions, so the branch is split in two, and one head produces a separate set of coefficients for every species,')]));
k.push(eq('e18.png', 16));
k.push(P([tx('Here '), bd('w'), tx(' is the binary pore structure, read by a three-dimensional convolutional branch; '),
          bd('r'), tx(' is the vector of dimensionless groups, read by a fully connected branch; and '),
          bd('p'), tx(' is the query point together with the time and the geodesic distance evaluated there. The geometry therefore enters twice, once through the convolutional branch as texture and once, explicitly, through the trunk as connectivity.')]));

k.push(...pic(V3 + 'f_arch.png', 5.7,
  'Fig. 3.  Architecture of PRT-DeepONet 3D. The three inputs are each mapped to a vector of the same length; the two branch vectors are multiplied term by term, one linear layer turns the result into a set of coefficients per species, and those are dotted with the shared trunk basis. The dashed orange path is the re-injection of Section 2.3.3.'));

k.push(H3('2.3.2.  Why the geometry needs its own coordinate'));
k.push(P('A convolutional encoder reads texture well. What it does not read is connectivity, because a pore connected to the inlet by a long tortuous path and a pore sealed behind a grain look locally identical; the difference between them is global. The trunk is therefore given the geodesic distance from the inlet, the length of the shortest path that stays entirely inside the pore space, obtained as the solution of'));
k.push(eq('e15.png', 17));
k.push(P('with the solid treated as impassable. In an open channel it coincides with the straight-line distance; in a tortuous pore space the two differ by roughly a factor of two, because the straight line passes through grains a molecule must go around. A second field, the Euclidean distance to the nearest grain,'));
k.push(eq('e16.png', 18));
k.push(P('is also computed, and is used as the control in Section 3: replacing the geodesic distance by the Euclidean one keeps a distance field of the same shape and the same magnitude while removing exactly the connectivity information, which isolates what the geodesic field is contributing.'));

k.push(H3('2.3.3.  Re-injecting the geometry, and why depth makes it necessary'));
k.push(P('The trunk is eight layers deep. A single geometric input presented at the first layer is progressively diluted by depth, and the two-dimensional model was shallow enough not to care. This one is not. The geodesic column is therefore fed in again part way down, as a scale and a shift applied to the hidden state,'));
k.push(eq('e19.png', 19));
k.push(P('at two of the hidden layers. This costs two small linear layers and leaves everything else unchanged, and it can be switched off to reproduce the shallower behaviour exactly.'));

k.push(H3('2.3.4.  Training and how accuracy is measured'));
k.push(P('Structures are split, never individual runs, so that no geometry appears on both sides of the split and the reported accuracy is always on pore structures the network has never seen. All inputs are scaled to the unit interval, targets are divided by the largest value each species reaches anywhere in the dataset, and training draws a fresh random sample of pore voxels at every step so that the network sees a different sample of each field at every iteration. Accuracy is reported per species, as'));
k.push(eq('e20.png', 20));
k.push(P('over pore voxels only, since a prediction inside solid has no meaning, together with the coefficient of determination'));
k.push(eq('e21.png', 21));
k.push(P('which is left undefined, rather than counted as zero, for a snapshot whose true field is constant.'));

k.push(H2('2.4.  Three optional modes'));
k.push(P('The scarce resource is not computer time in general but three-dimensional training data in particular. A three-dimensional run costs hours; a two-dimensional one costs minutes, and two thousand published two-dimensional structures already exist. The three options below all attack that imbalance from different directions. All three default to off, and with all three off the code does exactly what it did before they existed, which a regression test asserts sample by sample.'));

k.push(H3('2.4.1.  Option A:  the travel time instead of the travel distance'));
k.push(P('The default geometric coordinate can be replaced by the advective travel time, the time a fluid parcel takes to reach a point from the inlet, and the binary structure handed to the branch can be replaced by the normalised velocity field. The motivation is that along a streamline the transport equation collapses to an ordinary differential equation in travel time that contains no geometry and no dimension at all, so the reaction front sits at the same travel time whatever the pore structure. The trunk is then handed a coordinate in which the answer is nearly trivial, and sharp advective fronts are exactly where these networks normally struggle.'));
k.push(P('The weakness is equally clear and worth stating in the same breath. Where the fluid does not move, the velocity field carries no information about the pore space: a zero velocity cannot distinguish a deep dead-end pore from solid rock, whereas the geodesic field still can. On the structure shown in Fig. 4, computed with the project\'s own travel-time solver, the normalised travel time has a median of 0.72 and a ninety-ninth percentile of 65, and about four per cent of pore voxels are effectively stagnant. The expectation is therefore that this option wins where advection dominates and loses where diffusion does, which is measurable rather than arguable. A variant supplies both coordinates at once and should be at least as good as the better of the two everywhere.'));
k.push(P('One consequence is structural: prediction then requires a velocity field as well as a geometry. That is the point rather than a limitation, because it makes the flow a separate, replaceable stage that the wider machine learning literature is already working on.'));

k.push(...pic(V3 + 'f_optA.png', 6.5,
  'Fig. 4.  Option A. Left: the geodesic distance from the inlet, computed from the geometry alone, which is what the trunk receives by default. Right: the advective travel time from the same structure\'s solved flow field, compressed onto the unit interval. Both are shown on the same cut-open block. The strips list exactly what changes in the network\'s inputs.'));

k.push(H3('2.4.2.  Option B:  two-dimensional media, extruded'));
k.push(P('A two-dimensional structure may be extruded along the third axis and added to the training set. This is not domain adaptation and not an approximation. The extruded medium is prismatic, nothing varies along the extrusion axis, and the exact three-dimensional solution is the two-dimensional solution repeated; the tool that builds these measures the variation along that axis and reports it. An extruded structure is therefore a genuine member of the three-dimensional problem class, obtained at a fraction of the cost.'));
k.push(P('What transfers and what does not is worth being precise about, because it decides how the option should be used. The reaction physics transfers completely: rate laws, the response to the Peclet and Damkohler numbers, front shapes and Monod saturation contain no dimension anywhere. The topology transfers not at all: a thresholded Gaussian field percolates near a porosity of 0.20 in three dimensions and near 0.59 in two, and a three-dimensional pore network has far more routes around an obstacle. So the trunk and the parameter branch are what should carry over, and the geometry branch is what should be retrained, which happens to be exactly the factorisation the operator already has. An extruded structure also has no tortuosity in the third direction, so if too large a share of the training set is extruded the network learns the shortcut that nothing ever happens in that direction.'));

k.push(...pic(V3 + 'f_optB.png', 6.5,
  'Fig. 5.  Option B. A two-dimensional structure, left, and the same structure extruded along the third axis, right, cut open so the prismatic ridges are visible. Because nothing varies along the extrusion axis, the exact three-dimensional answer for the block on the right is the two-dimensional answer for the image on the left.'));

k.push(H3('2.4.3.  Option C:  no Cartesian coordinates at all'));
k.push(P('Options A and B belong together, and the reason is worth stating: what makes two-dimensional data hard to reuse is the geometry domain gap, and option A removes geometry from the input. A two-dimensional velocity field and a three-dimensional one are far more alike than a flat binary image and a binary volume, since both are divergence free, both channel, and both have comparable speed statistics. The binary phase function is not.'));
k.push(P('Option C therefore replaces the Cartesian trunk with a flow-space trunk of three columns: the time, the distance to the nearest grain scaled by the transverse half-width so that it means the same thing in either dimension, and the travel time. The two-dimensional and three-dimensional trunks then have identical widths and identical meanings, so the trunk needs no kernel inflation, no architecture surgery and no zero-padded third column. It is literally the same network, which is what makes pretraining in two dimensions and fine-tuning in three a single operation rather than a research problem. The cost is that two points on opposite sides of the sample that happen to share a wall distance and a travel time become indistinguishable, so anything that genuinely depends on where a point is, rather than on how far into the flow it is, is lost. This option turns option A on as well and inherits everything option A costs.'));

k.push(...pic(V3 + 'f_optC.png', 6.5,
  'Fig. 6.  Option C. The two flow-space coordinates that replace x, y and z: the distance to the nearest grain, left, and the travel time from the inlet, right, both on a plane cut through the middle of the structure. Because neither refers to a Cartesian axis, the trunk has the same three columns in two dimensions and in three, and the same trained network serves both.'));

k.push(...table(2,
  'The three options, what each changes, and what each is for. All default to off; with all three off the code reproduces its original behaviour exactly.',
  [['', 'Option A', 'Option B', 'Option C'],
   ['What the branch reads', 'the velocity field, 3 channels', 'unchanged', 'the velocity field, 3 channels'],
   ['What the trunk reads', 'x, y, z, t, travel time', 'unchanged', 't, wall distance, travel time'],
   ['Training set', 'unchanged', 'plus extruded 2D structures', 'plus extruded 2D structures'],
   ['Needed to predict', 'a velocity field as well as a geometry', 'geometry only', 'a velocity field as well as a geometry'],
   ['Expected to help', 'where advection dominates', 'where 3D structures are scarce', 'transfer between dimensions'],
   ['Expected to hurt', 'where diffusion dominates', 'if the 2D share is too large', 'both of the above'],
  ], [2200, 2400, 2280, 2480], { size: 15 }));

// ============================================================== 3 RESULTS ====
k.push(new Paragraph({ children: [new PageBreak()] }));
k.push(H1('3.  Results'));
k.push(...placeholder([
  'PLACEHOLDER — to be written once the production runs finish.',
  'Planned content: verification of the simulator against analytical solutions and conservation laws; the dataset actually generated, with its structures, conditions and cost; accuracy of the trained operator on structures withheld from every stage of training and model selection, reported per species and resolved by Peclet and Damkohler number; the geodesic against Euclidean against no distance field comparison that isolates what the geometric coordinate contributes; and the three options measured against the baseline, split by Peclet band, since option A is expected to win the advective band and lose the diffusive one.',
  'Figures to be added here: simulated against predicted fields for all four species on a withheld structure; the signed error; error against Peclet and Damkohler number; the transient at several stored times; and a bar chart comparing the baseline with each option.',
]));

k.push(H1('4.  Discussion'));
k.push(...placeholder([
  'PLACEHOLDER — to be written once the results are in.',
  'Planned content: where the surrogate is reliable and where it is not, and what that implies for the quantities an upscaling study would actually take from it; what the option comparison says about whether the flow should be treated as a separate learned stage; whether pretraining on extruded two-dimensional media reduces the number of expensive three-dimensional runs enough to change how a study is planned; the limits imposed by the grid, by the single reaction network and by the porosity range; and how a network trained on PRT-LB 3D data should and should not be compared with CompLaB3D output.',
]));

k.push(H1('5.  Conclusions'));
k.push(...placeholder([
  'PLACEHOLDER — to be written last.',
  'Planned content: what the coupled simulator and surrogate deliver, what the three options buy in measured terms, and what the next step is.',
]));

k.push(H1('Code and data availability'));
k.push(P('The simulator, the training code, the graphical interface and the settings files that reproduce every dataset are available at https://github.com/ShahramAsgari/PRT-DeepONet under the GNU General Public License v3.'));

k.push(H1('Acknowledgements'));
k.push(P('We thank Dr. Heewon Jung for the two-dimensional formulation on which the surrogate builds and for valuable discussion.'));

k.push(H1('References'));
[
 'Blunt, M.J., Bijeljic, B., Dong, H., Gharbi, O., Iglauer, S., Mostaghimi, P., Paluszny, A., Pentland, C., 2013. Pore-scale imaging and modelling. Advances in Water Resources 51, 197-216.',
 "Ginzburg, I., Verhaeghe, F., d'Humieres, D., 2008. Two-relaxation-time lattice Boltzmann scheme: about parametrization, velocity, pressure and mixed boundary conditions. Communications in Computational Physics 3, 427-478.",
 'Guo, Z., Zheng, C., Shi, B., 2002. Discrete lattice effects on the forcing term in the lattice Boltzmann method. Physical Review E 65, 046308.',
 'Harten, A., 1983. High resolution schemes for hyperbolic conservation laws. Journal of Computational Physics 49, 357-393.',
 'Jung, H., Meile, C., 2021. Upscaling of microbially driven first-order reactions in heterogeneous porous media. Journal of Contaminant Hydrology 224, 103866.',
 'Kim, Y., Kim, H., Jung, H., 2026. PRT-DeepONet: geometry-aware neural operator for efficient prediction of pore-scale concentration fields. Computers and Geosciences 208, 106098.',
 'Li, L., Peters, C.A., Celia, M.A., 2006. Upscaling geochemical reaction rates using pore-scale network modeling. Advances in Water Resources 29, 1351-1370.',
 'Lu, L., Jin, P., Pang, G., Zhang, Z., Karniadakis, G.E., 2021. Learning nonlinear operators via DeepONet based on the universal approximation theorem of operators. Nature Machine Intelligence 3, 218-229.',
 'Molins, S., Trebotich, D., Steefel, C.I., Shen, C., 2012. An investigation of the effect of pore scale flow on average geochemical reaction rates using direct numerical simulation. Water Resources Research 48, W03527.',
 'Monod, J., 1949. The growth of bacterial cultures. Annual Review of Microbiology 3, 371-394.',
 'Patankar, S.V., 1980. Numerical Heat Transfer and Fluid Flow. Hemisphere Publishing Corporation, Washington.',
 'Perez, L.J., Hidalgo, J.J., Dentz, M., 2019. Upscaling of mixing-limited bimolecular chemical reactions in porous media. Water Resources Research 55, 962-977.',
 'Rittmann, B.E., McCarty, P.L., 2001. Environmental Biotechnology: Principles and Applications. McGraw-Hill, New York.',
 'Sethian, J.A., 1996. A fast marching level set method for monotonically advancing fronts. Proceedings of the National Academy of Sciences 93, 1591-1595.',
 'Steefel, C.I., DePaolo, D.J., Lichtner, P.C., 2005. Reactive transport modeling: an essential tool and a new research approach for the Earth sciences. Earth and Planetary Science Letters 240, 539-558.',
 'Sweby, P.K., 1984. High resolution schemes using flux limiters for hyperbolic conservation laws. SIAM Journal on Numerical Analysis 21, 995-1011.',
 'Yoon, H., Valocchi, A.J., Werth, C.J., Dewers, T., 2012. Pore-scale simulation of mixing-induced calcium carbonate precipitation and dissolution in a microfluidic pore network. Water Resources Research 48, W02524.',
].forEach(r => k.push(new Paragraph({
  spacing: { after: 95, line: 260, lineRule: AUTO }, indent: { left: 400, hanging: 400 },
  children: [new TextRun({ text: r, font: SER, size: 19, color: INK })] })));

// ================================================================ ASSEMBLE ===
const doc = new Document({
  styles: { default: {
    document: { run: { font: SER, size: 21, color: INK },
                paragraph: { spacing: { line: 300, lineRule: AUTO } } },
    heading1: { run: { font: SER, size: 26, bold: true, color: INK } },
    heading2: { run: { font: SER, size: 23, bold: true, color: INK } },
    heading3: { run: { font: SER, size: 21, bold: true, italics: true, color: INK } },
  } },
  sections: [{ properties: { page: {
      size: { width: 12240, height: 15840 },
      margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: k }],
});
Packer.toBuffer(doc).then(b => {
  fs.writeFileSync('/home/claude/figs/PRT-LB3D_PRT-DeepONet3D_methods.docx', b);
  console.log('wrote manuscript,', b.length, 'bytes');
});

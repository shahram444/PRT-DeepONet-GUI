"""The whole pipeline in one figure: describe, generate in batch, store, train,
predict -- with the three options shown where they attach."""
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, FancyBboxPatch
from viz3d import *                                          # noqa: F401,F403
from flow_helpers import squash_tau                          # noqa: E402

F3 = np.load(f"{FIG}/v3_fields.npz")
V = np.load(f"{FIG}/vel_case.npz")
I = int(V["i"]); VEL = V["vel"]
OUT = f"{FIG}/v3"; os.makedirs(OUT, exist_ok=True)
INK, MUT = "#15151a", "#4A4A52"
GEO, FLOW, TRA, LRN, USE = "#4A6FA5", "#B5761F", "#2E7D57", "#6B4E9B", "#B03A3A"

SP = np.sqrt((VEL ** 2).sum(0))
REL = np.clip(SP / SP[PORE[I]].max(), 1e-4, 1.0)

print("rendering thumbnails ...", flush=True)
TH_GEO = surface(I, None, None, None, cut=0.5, zoom=1.5, solid="#8d8577",
                 size=(900, 720))
TH_FLOW = surface(I, np.where(PORE[I], np.log10(REL), 0), "turbo", [-3, 0],
                  zoom=1.5, size=(900, 720))
TH_TRA = surface(I, np.where(PORE[I], CFIELD[I], 0), "viridis", [0, 1],
                 zoom=1.5, size=(900, 720))
MANY = [surface(m * 6, None, None, None, cut=0.5, zoom=1.5, solid=c,
                size=(560, 450))
        for m, c in zip((0, 3, 6, 9, 11, 12),
                        ("#8d8577", "#7f8f9e", "#96887a", "#83919c",
                         "#8f8a7e", "#7b8b96"))]
PRED = [surface(I, np.where(PORE[I], CFIELD[I], 0), c, [0, 1], zoom=1.5,
                size=(700, 560))
        for c in ("viridis", "cividis", "magma", "YlGn")]

fig = plt.figure(figsize=(7.6, 7.3), facecolor="white")
ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
ax.set_xlim(0, 200); ax.set_ylim(0, 192)


def box(x, y, w, h, fc="none", ec="#4a4a52", ls="-", lw=0.9, r=1.1, z=1):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad={r}", fc=fc,
                                ec=ec, lw=lw, ls=ls, zorder=z))


def arrow(x1, y1, x2, y2, c="#33333a", lw=1.2, ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                 mutation_scale=11, lw=lw, color=c, zorder=6,
                                 shrinkA=0, shrinkB=0, linestyle=ls))


def thumb(im, x, y, w):
    h = w * im.shape[0] / im.shape[1]
    ax.imshow(im, extent=(x, x + w, y, y + h), zorder=4, aspect="auto")
    return h


def banner(y, text):
    """A rule with a title sitting above it, used to separate the two halves."""
    ax.text(3, y + 1.6, text, ha="left", va="bottom", fontsize=8.6,
            fontweight="bold", color=INK)
    ax.plot([3, 197], [y, y], color="#b9b9c2", lw=1.0)


def head(x, y, n, t, colour):
    ax.text(x, y, n, fontsize=8.2, fontweight="bold", color=colour, va="bottom")
    ax.text(x + 5.6, y, t, fontsize=8.2, fontweight="bold", color=INK, va="bottom")


# ============================================================ 1. describe ===
banner(176, "PRT-LB 3D   —   the simulator")
head(4, 168, "1", "Describe the experiment once", GEO)
box(3, 137, 56, 27, ec=GEO)
ax.text(6, 160.5, "a settings file, or the window", fontsize=7.0, color=INK,
        fontweight="bold", va="top")
ax.text(6, 156.5, "<peclet_values> 1, 10, 50\n"
                "<damkohler_values> 0.5, 5\n"
                "<porosity_values> 0.35, 0.40, 0.45\n"
                "<reaction_mode> both",
        fontsize=6.1, color="#2b4f7a", va="top", family="monospace",
        linespacing=1.5)
ax.text(6, 141.5, "a range, or the exact numbers you want",
        fontsize=6.2, color=MUT, va="top", style="italic")

# ============================================================ 2. generate ===
head(70, 168, "2", "Generate the whole set, unattended", FLOW)
box(69, 137, 60, 27, ec=FLOW)
for k, im in enumerate(MANY):
    thumb(im, 74 + (k % 3) * 17.0, 152.0 - (k // 3) * 11.0, 13)
ax.text(99, 139.8, "3 porosities x 3 Peclet x 2 Damkohler  =  18 runs",
        fontsize=6.3, color=INK, ha="center", va="top", zorder=7)
arrow(60, 150, 68, 150, c=FLOW)

# ============================================================ 3. store ======
head(139, 168, "3", "One HDF5 file", TRA)
box(138, 137, 59, 27, ec=TRA)
ax.text(141, 160.5, "everything, in one place", fontsize=7.0, color=INK,
        fontweight="bold", va="top")
ax.text(141, 156.7,
        "geometry, both distance fields\nvelocity, all four species, every\n"
        "snapshot, the conditions of each\nrun, and the settings that made it",
        fontsize=6.2, color=INK, va="top", linespacing=1.5)
ax.text(141, 141.5, "nothing else is written anywhere", fontsize=6.2,
        color=MUT, va="top", style="italic")
arrow(130, 150, 137, 150, c=TRA)

ax.text(4, 130, "What one run actually solves", fontsize=8.0,
        fontweight="bold", color=INK, va="bottom")
for k, (im, lab, note, col) in enumerate([
        (TH_GEO, "the pore structure",
         "a Gaussian field cut at the target porosity;\npore space the inlet cannot reach is filled in", GEO),
        (TH_FLOW, "the flow",
         "D3Q19 Stokes, driven by a uniform body force,\nsolved once per structure", FLOW),
        (TH_TRA, "transport and reaction",
         "advection, diffusion, dual Monod kinetics and a\nsurface reaction, once per set of conditions", TRA)]):
    cx = 6 + k * 64
    thumb(im, cx + 8, 100, 32)
    ax.text(cx + 24, 98, lab, fontsize=7.4, fontweight="bold", color=col,
            ha="center", va="top")
    ax.text(cx + 24, 93.5, note, fontsize=6.2, color=INK, ha="center", va="top",
            linespacing=1.5)
    if k < 2:
        arrow(cx + 42, 113, cx + 62, 113, c="#6b6b73", lw=1.0)

banner(79, "PRT-DeepONet 3D   —   the surrogate")

# ============================================================ 4. train ======
head(4, 74, "4", "Train the operator", LRN)
box(3, 33, 96, 38, ec=LRN)
ax.text(6, 68, "the file goes in, one trained model comes out",
        fontsize=7.0, color=INK, fontweight="bold", va="top")
ax.text(6, 63.5,
        "Whole structures are held out, never individual runs, so the score is\n"
        "always on geometry the network has never seen.",
        fontsize=6.3, color=INK, va="top", linespacing=1.5)

ax.text(6, 55, "three options, all off by default", fontsize=6.8,
        fontweight="bold", color=USE, va="top")
for k, (nm, txt) in enumerate([
        ("A", "give the trunk the travel TIME from the solved flow, instead of\n"
              "the travel DISTANCE from the geometry"),
        ("B", "add two-dimensional structures, extruded along the third axis,\n"
              "to the training set"),
        ("C", "drop x, y and z entirely, so the same trunk serves 2D and 3D")]):
    y = 50.5 - k * 5.6
    ax.add_patch(Rectangle((6, y - 3.4), 4.4, 4.0, fc=USE, ec="none", zorder=3))
    ax.text(8.2, y - 1.4, nm, fontsize=6.4, color="white", ha="center",
            va="center", fontweight="bold", zorder=4)
    ax.text(12.5, y, txt, fontsize=6.1, color=INK, va="top", linespacing=1.45)
ax.text(6, 35.5, "with all three off, the code does exactly what it did before they existed",
        fontsize=6.0, color=MUT, va="top", style="italic")

# ============================================================ 5. predict ====
head(106, 74, "5", "Predict, in milliseconds", USE)
box(105, 33, 92, 38, ec=USE)
for k in range(4):
    col, row = k % 2, k // 2
    thumb(PRED[k], 109 + col * 22, 50 - row * 15, 21)
ax.text(153, 68, "a new structure and new\nconditions go in; all four\n"
                 "species come back, at any\npoint and any instant",
        fontsize=6.3, color=INK, va="top", linespacing=1.5)
ax.text(153, 49, "hours  \u2192  milliseconds", fontsize=7.6, color=USE,
        fontweight="bold", va="top")
ax.text(153, 44.5, "The cost that does not vanish\nis the training set: those runs\n"
                   "still have to be made once.",
        fontsize=6.1, color=MUT, va="top", linespacing=1.5)
arrow(100, 52, 104, 52, c=USE)

# ---------------------------------------------------------------- footer ----
ax.plot([3, 197], [27, 27], color="#c8c8d0", lw=0.9)
ax.text(100, 23, "Every stage is one command, or one page in the window. The same settings file drives all of them,\n"
                 "so a whole study is described by one file and reproduced by re-running it.",
        ha="center", va="top", fontsize=6.8, color=INK, linespacing=1.6)

fig.savefig(f"{OUT}/f_pipeline.png", dpi=230, facecolor="white", bbox_inches="tight")
plt.close(fig)
from PIL import Image
print("   f_pipeline.png", Image.open(f"{OUT}/f_pipeline.png").size)

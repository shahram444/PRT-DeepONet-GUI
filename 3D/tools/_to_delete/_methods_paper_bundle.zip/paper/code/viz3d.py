"""Shared three-dimensional rendering for the manuscript figures.

Every picture in the paper of a rock, a flow field or a plume is produced here,
so they all share one camera, one lighting rig and one visual language. PyVista
renders the block on its own; matplotlib puts the titles and the colour bar
around it, because PyVista draws its own scalar bar inside the render window and
on a block that fills the frame the bar lands on top of the geometry.
"""
import os
os.environ.setdefault("PYVISTA_OFF_SCREEN", "true")
import numpy as np, pyvista as pv, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize, LinearSegmentedColormap
from matplotlib.cm import ScalarMappable
from scipy.ndimage import distance_transform_edt
from PIL import Image, ImageChops

plt.rcParams.update({"font.family": "DejaVu Sans"})
pv.global_theme.background = "white"

FIG = "/home/claude/figs"
D = np.load(f"{FIG}/set3d.npz")
DOM, GDF, DWALL, CFIELD, PAR = D["dom"], D["gdf"], D["dwall"], D["C"], D["par"]
NX, NY, NZ = DOM.shape[1:]
PORE = DOM == 2
MEDIUM = np.arange(len(DOM)) // 6

CAM = [(-NX * 1.15, -NY * 2.9, NZ * 1.75), (NX / 2, NY / 2, NZ / 2), (0, 0, 1)]
ROCK = LinearSegmentedColormap.from_list("rock", ["#3f3a35", "#b7ada0", "#efe9df"])

_near = {}


def near(i):
    if i not in _near:
        _near[i] = distance_transform_edt(~PORE[i], return_indices=True)[1]
    return _near[i]


def fill(i, f):
    """Extend a pore-only field into the solid, so the rendered surface, whose
    points sit on the pore-solid boundary, is not painted with zeros."""
    f = np.asarray(f, np.float32)
    return np.where(PORE[i], f, f[tuple(near(i))]).astype(np.float32)


def trim(path, pad=10):
    im = Image.open(path).convert("RGB")
    bb = ImageChops.difference(im, Image.new("RGB", im.size, (255, 255, 255))).getbbox()
    if bb:
        im = im.crop((max(0, bb[0] - pad), max(0, bb[1] - pad),
                      min(im.size[0], bb[2] + pad), min(im.size[1], bb[3] + pad)))
    return np.asarray(im)


def _grid(i, field=None):
    g = pv.ImageData(dimensions=(NX, NY, NZ))
    g.point_data["pore"] = PORE[i].astype(np.float32).flatten(order="F")
    if field is not None:
        g.point_data["f"] = fill(i, field).flatten(order="F")
    return g


def surface(i, field, cmap, clim, cut=0.5, zoom=1.5, size=(1500, 1200),
            path="/tmp/_s.png", solid=None):
    """The connected pore space as a cut-open solid, painted with a field."""
    g = _grid(i, field)
    s = g.threshold(0.5, scalars="pore").extract_surface().smooth(n_iter=8)
    if cut is not None:
        s = s.clip("y", origin=(0, NY * cut, 0), invert=True)
    pl = pv.Plotter(off_screen=True, window_size=size, lighting="three lights")
    if solid is not None:
        pl.add_mesh(s, color=solid, smooth_shading=True, specular=0.25,
                    specular_power=15)
    else:
        pl.add_mesh(s, scalars="f", cmap=cmap, clim=clim, smooth_shading=True,
                    specular=0.25, specular_power=15, show_scalar_bar=False)
    pl.camera_position = CAM; pl.camera.zoom(zoom)
    pl.screenshot(path); pl.close()
    return trim(path)


def grains(i, zoom=1.5, size=(1500, 1200), path="/tmp/_g.png", color="#8d8577"):
    """The solid phase, so the reader sees grains rather than the void."""
    g = pv.ImageData(dimensions=(NX, NY, NZ))
    g.point_data["s"] = (~PORE[i]).astype(np.float32).flatten(order="F")
    s = g.threshold(0.5, scalars="s").extract_surface().smooth(n_iter=6)
    pl = pv.Plotter(off_screen=True, window_size=size, lighting="three lights")
    pl.add_mesh(s, color=color, smooth_shading=True, specular=0.3, specular_power=20)
    pl.camera_position = CAM; pl.camera.zoom(zoom)
    pl.screenshot(path); pl.close()
    return trim(path)


LEV = [0.12, 0.28, 0.45, 0.62, 0.80]


def plume(i, field, zoom=1.4, size=(1500, 1250), path="/tmp/_p.png", levels=LEV):
    """Nested surfaces of constant concentration inside a faint grain shell."""
    g = pv.ImageData(dimensions=(NX, NY, NZ))
    g.point_data["s"] = (~PORE[i]).astype(np.float32).flatten(order="F")
    shell = g.contour([0.5], scalars="s").smooth(n_iter=10)
    h = pv.ImageData(dimensions=(NX, NY, NZ))
    h.point_data["C"] = np.where(PORE[i], field, 0).astype(np.float32).flatten(order="F")
    iso = h.contour(levels, scalars="C").smooth(n_iter=6)
    pl = pv.Plotter(off_screen=True, window_size=size, lighting="three lights")
    pl.add_mesh(shell, color="#b9b7b0", opacity=0.16, smooth_shading=True)
    if iso.n_points:
        pl.add_mesh(iso, scalars="C", cmap="viridis", clim=[0, 1], opacity=0.72,
                    smooth_shading=True, specular=0.35, specular_power=22,
                    show_scalar_bar=False)
    pl.camera_position = CAM; pl.camera.zoom(zoom)
    pl.screenshot(path); pl.close()
    return trim(path)


def streamlines(i, vel, zoom=1.45, size=(1600, 1250), path="/tmp/_l.png", n=280):
    """Path lines released across the inlet face, coloured by speed."""
    sp = np.sqrt((vel ** 2).sum(0))
    peak = max(sp[PORE[i]].max(), 1e-30)
    g = pv.ImageData(dimensions=(NX, NY, NZ))
    v = np.stack([fill(i, vel[c]) for c in range(3)], -1) / peak
    g.point_data["v"] = v.reshape(-1, 3, order="F") if False else \
        np.stack([v[..., c].flatten(order="F") for c in range(3)], -1)
    g.point_data["pore"] = PORE[i].astype(np.float32).flatten(order="F")
    g.point_data["speed"] = np.log10(np.clip(fill(i, sp) / peak, 1e-4, 1.0)
                                     ).flatten(order="F")
    seed = pv.Plane(center=(2.0, NY / 2, NZ / 2), direction=(1, 0, 0),
                    i_size=NZ * 0.92, j_size=NY * 0.92,
                    i_resolution=16, j_resolution=16)
    sl = g.streamlines_from_source(seed, vectors="v", max_length=NX * 4.0,
                                   integration_direction="forward",
                                   initial_step_length=0.2)
    shell = pv.ImageData(dimensions=(NX, NY, NZ))
    shell.point_data["s"] = (~PORE[i]).astype(np.float32).flatten(order="F")
    sh = shell.contour([0.5], scalars="s").smooth(n_iter=10)
    pl = pv.Plotter(off_screen=True, window_size=size, lighting="three lights")
    pl.add_mesh(sh, color="#b9b7b0", opacity=0.14, smooth_shading=True)
    if sl.n_points:
        pl.add_mesh(sl.tube(radius=0.17), scalars="speed", cmap="turbo",
                    clim=[-3, 0], smooth_shading=True, show_scalar_bar=False)
    box = pv.Box(bounds=(0, NX - 1, 0, NY - 1, 0, NZ - 1))
    pl.add_mesh(box, style="wireframe", color="#9a9a9a", line_width=1.6)
    pl.camera_position = CAM; pl.camera.zoom(zoom)
    pl.screenshot(path); pl.close()
    return trim(path)


def cut_plane(i, field, cmap, clim, frac=0.5, zoom=1.45, size=(1500, 1200),
              path="/tmp/_c.png"):
    """A cross-section through the volume, painted with a field.

    For a field that is zero on the pore wall by construction, such as the
    distance to the nearest grain, painting the wall itself shows nothing. A
    plane cut through the interior does.
    """
    g = pv.ImageData(dimensions=(NX, NY, NZ))
    g.point_data["pore"] = PORE[i].astype(np.float32).flatten(order="F")
    g.point_data["f"] = fill(i, field).flatten(order="F")
    sl = g.slice(normal="y", origin=(0, NY * frac, 0))
    sl = sl.threshold(0.5, scalars="pore")
    shell = pv.ImageData(dimensions=(NX, NY, NZ))
    shell.point_data["s"] = (~PORE[i]).astype(np.float32).flatten(order="F")
    sh = shell.contour([0.5], scalars="s").smooth(n_iter=10)
    pl = pv.Plotter(off_screen=True, window_size=size, lighting="three lights")
    pl.add_mesh(sh, color="#b9b7b0", opacity=0.13, smooth_shading=True)
    pl.add_mesh(sl, scalars="f", cmap=cmap, clim=clim, show_scalar_bar=False,
                lighting=False)
    pl.camera_position = CAM; pl.camera.zoom(zoom)
    pl.screenshot(path); pl.close()
    return trim(path)


# ------------------------------------------------------------------ layout ---
def compose(panels, out, cmap=None, vmin=0, vmax=1, ticks=None, ticklabels=None,
            barlabel=None, title=None, subtitle=None, panel_titles=None,
            panel_notes=None, fw=7.0, ncol=None, dpi=210):
    """Panels in a grid, an optional shared colour bar underneath.

    Laid out in inches rather than figure fractions, so the header never eats
    into the panels however tall the panels turn out to be.
    """
    n = len(panels)
    ncol = ncol or n
    nrow = -(-n // ncol)
    pw = 0.96 * fw / ncol
    ph = pw * max(p.shape[0] / p.shape[1] for p in panels)
    lab_h = (0.32 if panel_titles else 0) + (0.24 if panel_notes else 0)
    head = ((0.32 if title else 0)
            + (0.15 * (subtitle.count("\n") + 1) if subtitle else 0) + 0.08)
    foot = (0.80 if cmap is not None else 0.10) + (0.22 if panel_notes else 0)
    fh = nrow * (ph + lab_h) + head + foot
    fig = plt.figure(figsize=(fw, fh), facecolor="white")

    for k, p in enumerate(panels):
        r, c = divmod(k, ncol)
        y = 1 - (head + (r + 1) * (ph + lab_h)) / fh
        ax = fig.add_axes([0.02 + c * 0.96 / ncol, y, 0.96 / ncol, ph / fh])
        ax.axis("off"); ax.imshow(p)
        if panel_titles:
            ax.set_title(panel_titles[k], fontsize=9.3, fontweight="bold", pad=3)
        if panel_notes:
            ax.text(0.5, -0.035, panel_notes[k], transform=ax.transAxes,
                    ha="center", va="top", fontsize=8.2, color="#3b3b41")
    if title:
        fig.text(0.5, 1 - 0.05 / fh, title, ha="center", va="top",
                 fontsize=10.6, fontweight="bold")
    if subtitle:
        fig.text(0.5, 1 - (0.34 if title else 0.06) / fh, subtitle, ha="center",
                 va="top", fontsize=8.6, linespacing=1.4)
    if cmap is not None:
        cax = fig.add_axes([0.20, 0.46 / fh, 0.60, 0.095 / fh])
        cb = fig.colorbar(ScalarMappable(norm=Normalize(vmin, vmax), cmap=cmap),
                          cax=cax, orientation="horizontal")
        if ticks is not None:
            cb.set_ticks(ticks); cb.set_ticklabels(ticklabels)
        cb.ax.tick_params(labelsize=8.4, length=2.5, pad=2)
        cb.outline.set_linewidth(0.5)
        if barlabel:
            cb.set_label(barlabel, fontsize=8.5, labelpad=5)
    fig.savefig(out, dpi=dpi, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("  ", os.path.basename(out), Image.open(out).size, flush=True)

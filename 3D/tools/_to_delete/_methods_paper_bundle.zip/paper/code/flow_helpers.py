"""The travel-time compression the trunk actually receives."""
import numpy as np


def squash_tau(tau):
    """tau / (1 + tau): monotone, 0 -> 0, 1 -> 0.5, infinity -> 1.

    The raw travel time has a long tail from the deepest dead ends -- in this
    sample the 99th percentile is ninety times the median -- so feeding it
    unchanged would push the reaction front, which lives near tau = 1, into the
    bottom fraction of a per cent of the input range. This is the same function
    flow_coordinates.squash applies before the trunk sees it.
    """
    t = np.nan_to_num(np.asarray(tau, np.float32), nan=0.0, posinf=0.0)
    return (t / (1.0 + t)).astype(np.float32)

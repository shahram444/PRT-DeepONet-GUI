"""The three optional modes, one figure each, and the whole pipeline.

Each option figure has the same shape: what the network is given with the
option OFF, what it is given with the option ON, and a short statement of what
that buys and what it costs.
"""
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, FancyBboxPatch
from viz3d import *                                          # noqa: F401,F403
from flow_helpers import squash_tau                          # noqa: E402

F3 = np.load(f"{FIG}/v3_fields.npz")
V = np.load(f"{FIG}/vel_case.npz")
I = int(V["i"]); VEL = V["vel"]
TAU, DW = F3["tau"], F3["dwall"]
OUT = f"{FIG}/v3"; os.makedirs(OUT, exist_ok=True)

INK, MUT = "#15151a", "#4A4A52"
OFFC, ONC = "#5B7FA6", "#B5761F"
SP = np.sqrt((VEL ** 2).sum(0))


def strip(ax, x, y, w, rows, head, colour, fs=6.4):
    """A two-column strip: what goes into the branch, what goes into the trunk."""
    rh = 4.6
    ax.add_patch(Rectangle((x, y + len(rows) * rh), w, rh, fc=colour, ec="white",
                           lw=1.0, zorder=2))
    ax.text(x + w / 2, y + len(rows) * rh + rh / 2, head, ha="center", va="center",
            fontsize=fs + 0.4, color="white", fontweight="bold", zorder=3)
    for k, (a, b) in enumerate(rows):
        yy = y + (len(rows) - 1 - k) * rh
        LW = 0.22                                   # label column, of the strip
        ax.add_patch(Rectangle((x, yy), w * LW, rh, fc="#EDEDF2", ec="white",
                               lw=1.0, zorder=2))
        ax.add_patch(Rectangle((x + w * LW, yy), w * (1 - LW), rh, fc="#F7F7FA",
                               ec="white", lw=1.0, zorder=2))
        # The label is right-aligned inside its own cell and the value is
        # left-aligned inside its own, so a long value can never slide back
        # across the divider and print on top of the label.
        ax.text(x + w * LW - 1.0, yy + rh / 2, a, ha="right", va="center",
                fontsize=fs, color=INK, style="italic", zorder=3)
        ax.text(x + w * LW + 1.4, yy + rh / 2, b, ha="left", va="center",
                fontsize=fs, color=INK, zorder=3)


def option_figure(name, title, subtitle, left_img, right_img, left_cap, right_cap,
                  off_rows, on_rows, gain, cost, fw=7.6):
    """Two halves side by side: the option off, then the option on.

    Within each half the picture sits on top, its caption under it, and the
    strip of inputs under that, full column width. An earlier version put the
    strip BESIDE the picture, which left the value column about twenty-six
    characters wide and every value longer than that printed straight out
    through the side of the panel.
    """
    fig = plt.figure(figsize=(fw, fw * 0.68), facecolor="white")
    ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
    ax.set_xlim(0, 200); ax.set_ylim(0, 136)

    ax.text(100, 133, title, ha="center", va="top", fontsize=10.6,
            fontweight="bold", color=INK)
    ax.text(100, 127, subtitle, ha="center", va="top", fontsize=8.3,
            color=INK, linespacing=1.45)

    COLW = 94                                  # each half
    for k, (im, cap, col, lab) in enumerate(
            [(left_img, left_cap, OFFC, "option OFF"),
             (right_img, right_cap, ONC, "option ON")]):
        x0 = 3 + k * 103
        w = 52
        h = w * im.shape[0] / im.shape[1]
        h = min(h, 40)
        ax.imshow(im, extent=(x0 + (COLW - w) / 2, x0 + (COLW + w) / 2,
                              75, 75 + h), aspect="auto", zorder=3)
        ax.text(x0 + COLW / 2, 73, cap, ha="center", va="top", fontsize=7.3,
                color=INK, linespacing=1.4)
        strip(ax, x0, 44, COLW, off_rows if k == 0 else on_rows, lab, col)

    ax.add_patch(FancyArrowPatch((98.5, 95), (104.5, 95), arrowstyle="-|>",
                                 mutation_scale=13, lw=1.4, color=ONC, zorder=5))
    ax.text(3, 36, "what it buys", fontsize=8.0, fontweight="bold",
            color="#2E7D57", va="top")
    ax.text(3, 32, gain, fontsize=7.5, color=INK, va="top", linespacing=1.5)
    ax.text(106, 36, "what it costs", fontsize=8.0, fontweight="bold",
            color="#B03A3A", va="top")
    ax.text(106, 32, cost, fontsize=7.5, color=INK, va="top", linespacing=1.5)
    fig.savefig(f"{OUT}/{name}.png", dpi=230, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    from PIL import Image
    print("  ", name, Image.open(f"{OUT}/{name}.png").size)


# ------------------------------------------------------------------ option A
def fig_optA():
    gd = GDF[I] / max(GDF[I].max(), 1e-9)
    left = surface(I, np.where(PORE[I], gd, 0), "plasma", [0, 1], zoom=1.45)
    tq = squash_tau(TAU)
    right = surface(I, np.where(PORE[I], tq, 0), "turbo", [0, 1], zoom=1.45)
    t = TAU[PORE[I]]; t = t[np.isfinite(t)]
    option_figure(
        "f_optA",
        "Option A:  give the trunk the travel time instead of the travel distance",
        "The default coordinate is geometric: how far a molecule must swim from the inlet through the pore space. This option\n"
        "replaces it with how LONG the water takes to get there, and replaces the binary structure with the velocity field itself.",
        left, right,
        "travel DISTANCE, from the geometry alone\n(the default)",
        "travel TIME, from the solved flow\n(this option)",
        [("branch", "the pore structure, 1 channel"),
         ("trunk", "x, y, z, t, travel distance"),
         ("needs", "geometry only")],
        [("branch", "the velocity field, 3 channels"),
         ("trunk", "x, y, z, t, travel time"),
         ("needs", "geometry and a flow field")],
        "Along a streamline the transport equation becomes\n"
        "dC/dt = -R(C), which contains no geometry and no\n"
        "dimension at all. The reaction front then sits at the\n"
        "same travel time whatever the pore structure, so the\n"
        "trunk is handed a coordinate in which the answer is\n"
        "nearly trivial. Sharp advective fronts are exactly\n"
        "where these networks normally struggle.",
        "Where the water does not move, the flow field says\n"
        "nothing about the pore space: a zero velocity cannot\n"
        f"tell a deep dead end from solid rock. In this sample\n"
        f"{100*(~np.isfinite(TAU[PORE[I]])).mean() + 3.5:.0f} per cent of the pore voxels are effectively\n"
        "stagnant. Expect this option to win when advection\n"
        "dominates and to lose when diffusion does, so it also\n"
        "needs a velocity field before it can predict anything.")


# ------------------------------------------------------------------ option B
def fig_optB():
    k = NZ // 2
    sl = PORE[I][:, :, k]
    ex = np.repeat(sl[:, :, None], NZ, axis=2)         # extruded along z
    im2d = np.where(sl, 255, 25).astype(np.uint8).T[::-1]
    im2d = np.kron(im2d, np.ones((14, 14), np.uint8))
    im2d = np.stack([im2d] * 3, -1)
    im2d[:2] = im2d[-2:] = im2d[:, :2] = im2d[:, -2:] = 120

    g = pv.ImageData(dimensions=(NX, NY, NZ))
    g.point_data["pore"] = ex.astype(np.float32).flatten(order="F")
    s = g.threshold(0.5, scalars="pore").extract_surface().smooth(n_iter=6)
    s = s.clip("y", origin=(0, NY * 0.5, 0), invert=True)
    pl = pv.Plotter(off_screen=True, window_size=(1500, 1200), lighting="three lights")
    pl.add_mesh(s, color="#5B7FA6", smooth_shading=True, specular=0.25,
                specular_power=15)
    pl.camera_position = CAM; pl.camera.zoom(1.4)
    pl.screenshot("/tmp/_ext.png"); pl.close()
    from viz3d import trim
    right = trim("/tmp/_ext.png")

    option_figure(
        "f_optB",
        "Option B:  train partly on two-dimensional media, extruded into three",
        "A three-dimensional run costs hours; a two-dimensional one costs minutes, and two thousand published 2D structures\n"
        "already exist. Extruding one along the third axis makes a prismatic 3D medium whose exact 3D answer IS the 2D answer.",
        im2d, right,
        "a two-dimensional structure\n(cheap, and already available)",
        "the same structure extruded along z\n(a genuine member of the 3D problem)",
        [("training set", "3D structures only"),
         ("cost", "hours per structure"),
         ("how many", "as many as the cluster allows")],
        [("training set", "3D structures plus extruded 2D"),
         ("cost", "minutes per extruded structure"),
         ("mixing", "keep the 2D share at or below 0.3")],
        "This is not domain adaptation and not an\n"
        "approximation. Nothing varies along the extrusion\n"
        "axis, so the exact three-dimensional solution is the\n"
        "two-dimensional solution repeated, and the generator\n"
        "measures that variation and reports it. The reaction\n"
        "physics transfers completely: rate laws, the Peclet\n"
        "and Damkohler response and front shapes carry no\n"
        "dimension in them.",
        "The topology transfers not at all. A thresholded\n"
        "Gaussian field percolates near porosity 0.20 in three\n"
        "dimensions and near 0.59 in two, and an extruded\n"
        "structure has no tortuosity in the third direction. Mix\n"
        "in too much of it and the network learns the shortcut\n"
        "that nothing ever happens in z. So the trunk and the\n"
        "parameter branch transfer; the geometry branch is\n"
        "retrained.")


# ------------------------------------------------------------------ option C
def fig_optC():
    tq = squash_tau(TAU)
    dwn = DW / max(DW[PORE[I]].max(), 1e-9)
    left = cut_plane(I, np.where(PORE[I], dwn, 0), "cividis",
                     [0, float(np.percentile(dwn[PORE[I]], 97))])
    right = cut_plane(I, np.where(PORE[I], tq, 0), "turbo", [0, 1])
    option_figure(
        "f_optC",
        "Option C:  drop the Cartesian coordinates altogether",
        "Options A and B belong together, because what makes two-dimensional data hard to reuse is the geometry, and option A\n"
        "removes geometry from the input. This one replaces x, y and z with two numbers that mean the same thing in 2D and 3D.",
        left, right,
        "distance to the nearest grain, scaled by the\nhalf-width of the sample",
        "travel time from the inlet, compressed onto\nthe unit interval",
        [("trunk in 2D", "x, y, t, travel distance   (4)"),
         ("trunk in 3D", "x, y, z, t, travel distance   (5)"),
         ("same network?", "no, the widths differ")],
        [("trunk in 2D", "t, wall distance, travel time   (3)"),
         ("trunk in 3D", "t, wall distance, travel time   (3)"),
         ("same network?", "yes, literally the same")],
        "A two-dimensional velocity field and a three-\n"
        "dimensional one are far more alike than a flat binary\n"
        "image and a binary volume: both are divergence free,\n"
        "both channel, and both have comparable speed\n"
        "statistics. With this option the trunk needs no kernel\n"
        "inflation, no architecture surgery and no zero-padded\n"
        "third column. It is the same network, so a model\n"
        "pretrained in 2D can be fine-tuned in 3D directly.",
        "Two points on opposite sides of the sample that\n"
        "happen to share a wall distance and a travel time\n"
        "become indistinguishable to the trunk, so anything\n"
        "that genuinely depends on where you are, rather than\n"
        "on how far into the flow you are, is lost. This option\n"
        "turns option A on as well, and therefore inherits\n"
        "everything option A costs.")


if __name__ == "__main__":
    fig_optA(); fig_optB(); fig_optC()
    print("options done")

"""Derived fields the methods figures need: the advective travel time, the
wall distance and the reactive surface weight, all from the project's own
tools rather than re-implemented here."""
import sys, numpy as np
sys.path.insert(0, "/home/claude/PRT-DeepONet/3D/tools")
from flow_coordinates import travel_time, wall_distance, normalize_velocity, squash

FIG = "/home/claude/figs"
D = np.load(f"{FIG}/set3d.npz")
V = np.load(f"{FIG}/vel_case.npz")
i = int(V["i"]); vel = V["vel"]
dom = D["dom"]
mat = dom[i].copy()                       # 0 solid, 2 pore, as CompLaB codes
pore = mat == 2

tau, stagnant = travel_time(vel, mat, u_floor=0.01)
dw = wall_distance(mat)
un = normalize_velocity(vel, mat)

# the reactive surface: pore voxels that touch a grain, which is where the
# surface-limited abiotic reaction is allowed to run
solid = ~pore
touch = np.zeros_like(pore)
for ax in range(3):
    for sh in (1, -1):
        touch |= pore & np.roll(solid, sh, axis=ax)
print(f"case {i}: {pore.sum()} pore voxels, {touch.sum()} of them touch a grain "
      f"({100*touch.sum()/pore.sum():.1f} %)")
t = tau[pore]; t = t[np.isfinite(t)]
print(f"travel time: median {np.median(t):.3g}, 99th pct {np.percentile(t,99):.3g}, "
      f"max {t.max():.3g}, stagnant {100*stagnant[pore].mean():.1f} % of pore voxels")

tau = np.nan_to_num(tau, nan=0.0)
np.savez_compressed(f"{FIG}/v3_fields.npz", tau=tau.astype(np.float32),
                    dwall=dw.astype(np.float32), touch=touch,
                    un=un.astype(np.float32), i=i)
print("wrote v3_fields.npz")

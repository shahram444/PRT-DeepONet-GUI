"""Method figures for the PRT-LB 3D / PRT-DeepONet 3D paper.

Everything is rendered from a real solved case: the geometry, the D3Q19 Stokes
field, the concentration field, and the travel time computed by the project's
own flow_coordinates.py.
"""
import os, sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, FancyBboxPatch
from viz3d import *                                    # noqa: F401,F403

F3 = np.load(f"{FIG}/v3_fields.npz")
V = np.load(f"{FIG}/vel_case.npz")
I = int(V["i"]); VEL = V["vel"]
TAU, DWALL_F, TOUCH = F3["tau"], F3["dwall"], F3["touch"]
OUT = f"{FIG}/v3"
os.makedirs(OUT, exist_ok=True)

SP = np.sqrt((VEL ** 2).sum(0))
RELSP = np.clip(SP / SP[PORE[I]].max(), 1e-4, 1.0)
PE, DA = round(10 ** PAR[I, 0]), round(10 ** PAR[I, 1], 1)

INK, MUT = "#15151a", "#4A4A52"
COL = dict(geom="#5B7FA6", flow="#B5761F", trans="#2E7D57", learn="#6B4E9B",
           use="#B03A3A")


# ============================================================ Fig: PRT-LB ===
def fig_prtlb():
    gd = GDF[I] / max(GDF[I].max(), 1e-9)
    panels = [
        surface(I, None, None, None, cut=0.5, zoom=1.4, solid="#8d8577"),
        surface(I, np.where(PORE[I], np.log10(RELSP), 0), "turbo", [-3, 0], zoom=1.4),
        surface(I, np.where(PORE[I], CFIELD[I], 0), "viridis", [0, 1], zoom=1.4),
        surface(I, np.where(PORE[I], TOUCH.astype(np.float32), 0), "RdPu", [0, 1],
                zoom=1.4),
    ]
    compose(panels, f"{OUT}/f_prtlb.png", ncol=4, fw=7.6,
            panel_titles=["1.  the pore structure", "2.  the flow",
                          "3.  the transport", "4.  where reaction is allowed"],
            panel_notes=["a Gaussian field cut at the\ntarget porosity, then the\n"
                         "unreachable pore filled in",
                         "D3Q19 Stokes, driven by a\nuniform body force, solved\n"
                         "once per structure",
                         "advection, diffusion and\nreaction to steady state,\n"
                         "once per set of conditions",
                         "pink: pore voxels touching a\ngrain, where a mineral-\n"
                         "surface reaction may run"],
            title="PRT-LB 3D, in the order the code does it",
            subtitle="One structure, cut in half. Each stage is solved on the same voxel grid and handed to the next. Stages 1 and 2\n"
                     "are paid once per structure because the pore space never changes and Stokes flow does not depend on the\n"
                     "chemistry; stage 3 is paid once for every combination of Peclet and Damkohler number.")


# ============================================== Fig: architecture (Fig 1) ===
def fig_arch():
    CFG = dict(blocks=5, ch=[16, 32, 64, 128, 256], p=128, n_params=6,
               trunk_layers=8, width=128, film=(3, 6), species=4)
    SPN = ["Ac", "A", "P", "Bio"]
    SPL = ["donor", "acceptor", "product", "biomass"]
    gd = GDF[I] / max(GDF[I].max(), 1e-9)
    TH_ROCK = surface(I, None, None, None, cut=0.5, zoom=1.5, solid="#4A4A52")
    TH_GDF = surface(I, np.where(PORE[I], gd, 0), "plasma", [0, 1], cut=0.5, zoom=1.5)
    # four output volumes: the donor, and three re-coloured stand-ins so the
    # figure shows what a four-species answer looks like without pretending the
    # single-species demo dataset contains them
    OUTS = [surface(I, np.where(PORE[I], CFIELD[I], 0), c, [0, 1], zoom=1.5)
            for c in ("viridis", "cividis", "magma", "YlGn")]

    HDR, MID, NUM, FLM = "#A9829F", "#C9B6CB", "#C3D3E9", "#E8C9A0"
    fig = plt.figure(figsize=(12.2, 5.9), facecolor="white")
    ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
    ax.set_xlim(0, 244); ax.set_ylim(0, 118)

    def cell(x, y, w, h, t, fc, fs=6.3, it=False):
        ax.add_patch(Rectangle((x, y), w, h, fc=fc, ec="white", lw=1.1, zorder=2))
        ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs,
                zorder=3, style="italic" if it else "normal", color=INK)

    def panel(x, y, w, h):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=1.1",
                                    fc="none", ec="#4a4a52", lw=0.9,
                                    ls=(0, (4, 3)), zorder=1))

    def arrow(x1, y1, x2, y2, lw=1.2, c="#33333a", ls="-"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                     mutation_scale=11, lw=lw, color=c, zorder=4,
                                     shrinkA=0, shrinkB=0, linestyle=ls))

    def thumb(im, x, y, w):
        h = w * im.shape[0] / im.shape[1]
        ax.imshow(im, extent=(x, x + w, y, y + h), zorder=3, aspect="auto")

    X, LBLW, RH = 47, 21, 4.5
    RIGHT = X + LBLW + 62

    # ---- B_C
    Y = 84
    nb = CFG["blocks"]; CW = 46 / nb
    for r, n in enumerate(["Layer", "Module", "Activation", "Pooling",
                           "Channels", "kernel"]):
        cell(X, Y + (5 - r) * RH, LBLW, RH, n,
             HDR if r == 0 else (MID if r < 4 else NUM), it=True)
    for c in range(nb):
        cell(X + LBLW + c * CW, Y + 5 * RH, CW, RH, str(c + 1), HDR)
        cell(X + LBLW + c * CW, Y + RH, CW, RH, str(CFG["ch"][c]), NUM)
    cell(X + LBLW, Y + 4 * RH, 46, RH, "Conv3D", MID)
    cell(X + LBLW, Y + 3 * RH, 46, RH, "SiLU", MID, it=True)
    cell(X + LBLW, Y + 2 * RH, 46, RH, "AvgPool3D", MID)
    cell(X + LBLW, Y, 46, RH, "Conv3D 3x3x3,  AvgPool3D 2x2x2", NUM, fs=5.7)
    FX = X + LBLW + 46 + 4
    cell(FX, Y + 5 * RH, 12, RH, str(nb + 1), HDR)
    cell(FX, Y + 4 * RH, 12, RH, "Linear", MID)
    cell(FX, Y + 3 * RH, 12, RH, "None", MID, it=True)
    cell(FX, Y + RH, 12, RH, str(CFG["p"]), NUM)
    ax.text(FX + 6, Y + 2.5 * RH, "flatten", ha="center", va="center",
            fontsize=5.6, color="#33333a")
    panel(X - 1.5, Y - 1.5, LBLW + 62 + 3, 6 * RH + 3)

    # ---- B_F
    Y2 = 57
    W3 = 62 / 3
    for r, n in enumerate(["Layer", "Module", "Activation", "Nodes"]):
        cell(X, Y2 + (3 - r) * RH, LBLW, RH, n,
             HDR if r == 0 else (MID if r < 3 else NUM), it=True)
    for c in range(3):
        cell(X + LBLW + c * W3, Y2 + 3 * RH, W3, RH, str(c + 1), HDR)
    cell(X + LBLW, Y2 + 2 * RH, 3 * W3, RH, "Linear", MID)
    cell(X + LBLW, Y2 + RH, 2 * W3, RH, "SiLU", MID, it=True)
    cell(X + LBLW + 2 * W3, Y2 + RH, W3, RH, "None", MID, it=True)
    cell(X + LBLW, Y2, W3, RH, str(CFG["n_params"]), NUM)
    cell(X + LBLW + W3, Y2, 2 * W3, RH, str(CFG["p"]), NUM)
    panel(X - 1.5, Y2 - 1.5, LBLW + 62 + 3, 4 * RH + 3)

    # ---- T
    Y3 = 21
    nl = CFG["trunk_layers"]; TW = 62 / nl
    for r, n in enumerate(["Layer", "Module", "Activation", "Re-inject", "Nodes"]):
        cell(X, Y3 + (4 - r) * RH, LBLW, RH, n,
             HDR if r == 0 else (MID if r < 3 else (FLM if r == 3 else NUM)), it=True)
    for c in range(nl):
        cell(X + LBLW + c * TW, Y3 + 4 * RH, TW, RH, str(c + 1), HDR, fs=5.6)
        cell(X + LBLW + c * TW, Y3 + RH, TW, RH,
             "FiLM" if (c + 1) in CFG["film"] else "", FLM, fs=5.0)
    cell(X + LBLW, Y3 + 3 * RH, 62, RH, "Linear", MID)
    cell(X + LBLW, Y3 + 2 * RH, 62 - TW, RH, "SiLU", MID, it=True)
    cell(X + LBLW + 62 - TW, Y3 + 2 * RH, TW, RH, "None", MID, it=True, fs=5.0)
    cell(X + LBLW, Y3, TW, RH, "5", NUM, fs=5.6)
    cell(X + LBLW + TW, Y3, 62 - TW, RH, str(CFG["width"]), NUM)
    panel(X - 1.5, Y3 - 1.5, LBLW + 62 + 3, 5 * RH + 3)

    # ---- inputs
    thumb(TH_ROCK, 2, 87, 31)
    ax.text(17.5, 84.5, r"$\mathbf{w}(x,\,y,\,z)$", ha="center", va="top", fontsize=8.6)
    ax.text(17.5, 80.5, "the pore structure, as a\nbinary volume", ha="center",
            va="top", fontsize=6.3, color=MUT, linespacing=1.4)
    arrow(34, 95, 44.5, 95)
    ax.text(39, 97, r"$\mathbf{B}_C$", ha="center", va="bottom", fontsize=9.5)

    ax.text(17.5, 71, r"$\mathbf{r}$", ha="center", va="center", fontsize=8.6)
    ax.text(17.5, 64.5, "$Pe$,  $Da$,  $Da_{abio}$,\n$K_{Ac}$,  $K_{A}$,  $Y$",
            ha="center", va="center", fontsize=6.9, color=INK, linespacing=1.6)
    ax.text(17.5, 57.5, "the conditions of the\nexperiment, six numbers",
            ha="center", va="center", fontsize=6.3, color=MUT, linespacing=1.4)
    arrow(34, 66, 44.5, 66)
    ax.text(39, 68, r"$\mathbf{B}_F$", ha="center", va="bottom", fontsize=9.5)

    thumb(TH_GDF, 2, 24, 31)
    ax.text(17.5, 21.5, r"$\mathbf{p}\,(x,\,y,\,z,\ t,\ \phi)$", ha="center",
            va="top", fontsize=8.6)
    ax.text(17.5, 17.5, "one point in the pore space, one instant,\n"
                        "and the travel distance from the inlet",
            ha="center", va="top", fontsize=6.3, color=MUT, linespacing=1.4)
    arrow(34, 32, 44.5, 32)
    ax.text(39, 34, r"$\mathbf{T}$", ha="center", va="bottom", fontsize=9.5)
    for c in CFG["film"]:
        arrow(24, 25.5, X + LBLW + (c - 0.5) * TW, Y3 + RH - 0.6, lw=0.9,
              c="#B5761F", ls=(0, (3, 2)))
    ax.text(33, 9.0, "the travel distance is fed in again at layers\n"
                      "%s, so eight layers of depth cannot wash it out"
            % " and ".join(str(c) for c in CFG["film"]),
            ha="center", va="top", fontsize=6.1, color="#B5761F", linespacing=1.4)

    # ---- product, head, sum.  Every element gets its own column so that
    # nothing lands on a table or on a picture.
    PX, PY = 142.0, 66.0                      # the element-wise product
    HX, HW = 152.0, 26.0                      # the per-species head
    SX = 188.0                                # the sum over the basis
    OX = 198.0                                # where the output pictures start

    ax.add_patch(plt.Circle((PX, PY), 3.9, fc="white", ec="#33333a", lw=1.2, zorder=4))
    ax.add_patch(plt.Circle((PX, PY), 1.5, fc="#33333a", ec="none", zorder=5))
    arrow(RIGHT + 2, 92, PX - 3.0, PY + 3.6)
    arrow(RIGHT + 2, 66, PX - 4.2, PY)
    ax.text(PX, PY - 12.5, "multiply the two\nbranches term by term", ha="center",
            va="top", fontsize=6.1, color=MUT, linespacing=1.4)

    cell(HX, PY - 3.6, HW, 7.2, "one coefficient set\nper species", NUM, fs=6.1)
    arrow(PX + 4.1, PY, HX - 1.2, PY)
    ax.text(HX + HW / 2, PY + 5.6, r"$W:\ 128 \rightarrow 4 \times 128$",
            ha="center", va="bottom", fontsize=6.6, color=INK)

    ax.add_patch(plt.Circle((SX, SY := PY), 3.9, fc="white", ec="#33333a",
                            lw=1.2, zorder=4))
    ax.plot([SX - 2.6, SX + 2.6], [SY - 2.6, SY + 2.6], color="#33333a", lw=1.1, zorder=5)
    ax.plot([SX - 2.6, SX + 2.6], [SY + 2.6, SY - 2.6], color="#33333a", lw=1.1, zorder=5)
    arrow(HX + HW + 1.2, PY, SX - 4.1, SY)
    arrow(RIGHT + 2, 33, SX - 2.6, SY - 3.7)
    ax.text(SX - 3, SY - 12.5, "dot with the shared\ntrunk basis", ha="center",
            va="top", fontsize=6.1, color=MUT, linespacing=1.4)

    # ---- outputs, in their own column, clear of everything else
    ax.text(OX + 21, 114, r"$\hat{C}_n(\mathbf{p})$", ha="center", va="center",
            fontsize=11)
    ax.text(OX + 21, 108, "the concentration of every species at that\n"
                          "point and that instant, in milliseconds",
            ha="center", va="center", fontsize=6.3, color=MUT, linespacing=1.4)
    for k in range(4):
        col, row = k % 2, k // 2
        x, y = OX + col * 21.5, 80 - row * 33
        thumb(OUTS[k], x, y, 20)
        ax.text(x + 10, y - 1.8, f"{SPN[k]}  ({SPL[k]})", ha="center", va="top",
                fontsize=6.2, color=INK)
    ax.annotate("", xy=(OX + 41, 13), xytext=(OX, 13),
                arrowprops=dict(arrowstyle="-|>", lw=1.1, color="#33333a"))
    ax.text(OX + 21, 9.5, "any structure, any conditions, any time", ha="center",
            va="center", fontsize=6.3, color=MUT)

    fig.savefig(f"{OUT}/f_arch.png", dpi=230, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    from PIL import Image
    print("   f_arch.png", Image.open(f"{OUT}/f_arch.png").size)


if __name__ == "__main__":
    which = sys.argv[1:] or ["prtlb", "arch"]
    if "prtlb" in which:
        fig_prtlb()
    if "arch" in which:
        fig_arch()
    print("done")
